"use client"

import { useMemo, useState } from "react"
import dynamic from "next/dynamic"
import { Activity, CircuitBoard, Layers, X, Zap } from "lucide-react"
import { PLANT_EQUIPMENT, activeFaults } from "@/lib/plant-data"
import { EquipmentList } from "@/components/equipment-list"
import { EquipmentDetail } from "@/components/equipment-detail"

const PlantScene = dynamic(
  () => import("@/components/scene/plant-scene").then((m) => m.PlantScene),
  {
    ssr: false,
    loading: () => (
      <div className="flex h-full w-full items-center justify-center text-sm text-muted-foreground">
        Loading 3D facility…
      </div>
    ),
  },
)

export function FacilityDashboard() {
  const [selectedTag, setSelectedTag] = useState<string | null>("R101")

  const selected = useMemo(
    () => PLANT_EQUIPMENT.find((e) => e.tag === selectedTag) ?? null,
    [selectedTag],
  )

  const kpis = useMemo(() => {
    const running = PLANT_EQUIPMENT.filter((e) => e.status === "running").length
    const alarms = PLANT_EQUIPMENT.reduce((n, e) => n + activeFaults(e).length, 0)
    const power = PLANT_EQUIPMENT.reduce((n, e) => n + e.energy.powerKw, 0)
    return { running, alarms, power }
  }, [])

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-background text-foreground">
      {/* Header */}
      <header className="z-20 flex flex-wrap items-center justify-between gap-3 border-b border-border bg-card px-4 py-3">
        <div className="flex items-center gap-3">
          <span className="flex h-9 w-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <CircuitBoard className="h-5 w-5" />
          </span>
          <div>
            <h1 className="text-sm font-semibold leading-tight text-balance">
              Toluene Disproportionation — Smart Facility
            </h1>
            <p className="font-mono text-[11px] text-muted-foreground">
              CUDA-linked equipment digital twin
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Kpi icon={<Activity className="h-3.5 w-3.5" />} label="Running" value={`${kpis.running}/${PLANT_EQUIPMENT.length}`} />
          <Kpi icon={<Zap className="h-3.5 w-3.5" />} label="Load" value={`${(kpis.power / 1000).toFixed(2)} MW`} />
          <Kpi
            icon={<Zap className="h-3.5 w-3.5" />}
            label="Alarms"
            value={String(kpis.alarms)}
            danger={kpis.alarms > 0}
          />
        </div>
      </header>

      {/* Main viewport with floating HUD panels */}
      <main className="relative flex-1">
        <div className="absolute inset-0">
          <PlantScene selectedTag={selectedTag} onSelect={setSelectedTag} />
        </div>

        {/* Overlay layer */}
        <div className="pointer-events-none absolute inset-0 flex justify-between gap-3 p-3">
          {/* Left: unit list */}
          <div className="pointer-events-auto flex w-60 shrink-0 flex-col gap-3">
            <div className="rounded-lg border border-border bg-card/85 p-3 backdrop-blur-md">
              <h2 className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                <Layers className="h-3.5 w-3.5" />
                Plant Units
              </h2>
              <EquipmentList selectedTag={selectedTag} onSelect={setSelectedTag} />
            </div>
            <Legend />
          </div>

          {/* Right: detail panel */}
          {selected && (
            <div className="pointer-events-auto ml-auto flex w-[22rem] max-w-[85vw] flex-col overflow-hidden rounded-lg border border-border bg-card/90 backdrop-blur-md">
              <div className="flex items-center justify-between border-b border-border px-3 py-2">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                  Equipment Inspector
                </span>
                <button
                  type="button"
                  onClick={() => setSelectedTag(null)}
                  className="rounded p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                  aria-label="Close inspector"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="min-h-0 flex-1">
                <EquipmentDetail equipment={selected} />
              </div>
            </div>
          )}
        </div>

        {/* Hint */}
        <p className="pointer-events-none absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full border border-border bg-card/80 px-3 py-1 text-[11px] text-muted-foreground backdrop-blur-md">
          Drag to orbit · scroll to zoom · click a unit to inspect
        </p>
      </main>
    </div>
  )
}

function Kpi({
  icon,
  label,
  value,
  danger,
}: {
  icon: React.ReactNode
  label: string
  value: string
  danger?: boolean
}) {
  return (
    <div
      className="flex items-center gap-2 rounded-md border px-2.5 py-1.5"
      style={{
        borderColor: danger ? "var(--status-fault)" : "var(--border)",
        background: danger ? "color-mix(in oklch, var(--status-fault) 12%, transparent)" : "var(--secondary)",
      }}
    >
      <span style={{ color: danger ? "var(--status-fault)" : "var(--primary)" }}>{icon}</span>
      <div className="leading-none">
        <div className="text-[10px] text-muted-foreground">{label}</div>
        <div
          className="font-mono text-sm font-semibold"
          style={{ color: danger ? "var(--status-fault)" : "var(--foreground)" }}
        >
          {value}
        </div>
      </div>
    </div>
  )
}

function Legend() {
  const items = [
    { label: "Running", token: "var(--status-run)" },
    { label: "Standby", token: "var(--status-standby)" },
    { label: "Fault", token: "var(--status-fault)" },
    { label: "Idle", token: "var(--status-idle)" },
  ]
  return (
    <div className="rounded-lg border border-border bg-card/85 p-3 backdrop-blur-md">
      <h2 className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
        Status Legend
      </h2>
      <ul className="grid grid-cols-2 gap-1.5">
        {items.map((i) => (
          <li key={i.label} className="flex items-center gap-2 text-xs text-foreground">
            <span
              className="inline-block h-2.5 w-2.5 rounded-full"
              style={{ background: i.token, boxShadow: `0 0 6px ${i.token}` }}
            />
            {i.label}
          </li>
        ))}
      </ul>
    </div>
  )
}
