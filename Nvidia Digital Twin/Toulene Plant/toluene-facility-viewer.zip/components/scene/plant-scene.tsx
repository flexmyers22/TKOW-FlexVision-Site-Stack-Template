"use client"

import { Canvas } from "@react-three/fiber"
import { OrbitControls, Environment, ContactShadows, Grid } from "@react-three/drei"
import { EquipmentMesh } from "./equipment-mesh"
import { PipeRun } from "./pipe-run"
import { PLANT_EQUIPMENT, PLANT_PIPES, type Equipment } from "@/lib/plant-data"
import { FLOOR_COLOR } from "@/lib/scene-colors"

interface PlantSceneProps {
  selectedTag: string | null
  onSelect: (tag: string | null) => void
}

export function PlantScene({ selectedTag, onSelect }: PlantSceneProps) {
  const byTag = (tag: string) => PLANT_EQUIPMENT.find((e) => e.tag === tag) as Equipment

  return (
    <Canvas
      shadows
      camera={{ position: [10, 9, 16], fov: 42 }}
      dpr={[1, 2]}
      onPointerMissed={() => onSelect(null)}
    >
      <color attach="background" args={[FLOOR_COLOR]} />
      <fog attach="fog" args={[FLOOR_COLOR, 24, 48]} />

      <ambientLight intensity={0.5} />
      <directionalLight
        position={[8, 14, 6]}
        intensity={1.6}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-20}
        shadow-camera-right={20}
        shadow-camera-top={20}
        shadow-camera-bottom={-20}
      />
      <Environment preset="warehouse" />

      {/* Plant floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.02, 0]} receiveShadow>
        <planeGeometry args={[60, 60]} />
        <meshStandardMaterial color={FLOOR_COLOR} metalness={0.1} roughness={0.9} />
      </mesh>
      <Grid
        position={[0, 0, 0]}
        args={[60, 60]}
        cellSize={1}
        cellThickness={0.6}
        cellColor="#333a44"
        sectionSize={5}
        sectionThickness={1}
        sectionColor="#454d59"
        fadeDistance={42}
        fadeStrength={1.5}
        infiniteGrid
      />

      <ContactShadows position={[0, 0.01, 0]} opacity={0.5} scale={50} blur={2.2} far={12} />

      {/* Pipe network */}
      {PLANT_PIPES.map((pipe) => {
        const a = byTag(pipe.from)
        const b = byTag(pipe.to)
        const active = a.status === "running" && b.status !== "idle"
        return (
          <PipeRun key={`${pipe.from}-${pipe.to}`} from={a.position} to={b.position} active={active} />
        )
      })}

      {/* Equipment units */}
      {PLANT_EQUIPMENT.map((eq) => (
        <EquipmentMesh
          key={eq.tag}
          equipment={eq}
          selected={selectedTag === eq.tag}
          onSelect={onSelect}
        />
      ))}

      <OrbitControls
        makeDefault
        enablePan
        minDistance={6}
        maxDistance={40}
        maxPolarAngle={Math.PI / 2.1}
        target={[0, 1.5, 2]}
      />
    </Canvas>
  )
}
