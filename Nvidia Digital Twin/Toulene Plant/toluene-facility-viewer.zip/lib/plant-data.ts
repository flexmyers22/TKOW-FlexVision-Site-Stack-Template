// Data model for the toluene disproportionation smart facility.
// Mirrors src/types/{equipment,binary,cuda,metrics}.ts and plant/equipment/*.json

export type EquipmentType = "reactor" | "pump" | "heater" | "column" | "tank"

export type OperationalStatus = "running" | "standby" | "idle" | "fault"

// A single addressable binary flag in an equipment's state register.
export interface BinaryFlag {
  bit: number
  key: string
  label: string
  value: 0 | 1
  // Whether a 1 in this bit is a healthy/expected condition.
  activeIsHealthy: boolean
}

export interface ThermalState {
  temperatureC: number
  setpointC: number
  // 0..1 fraction of thermal design duty currently used.
  dutyFraction: number
}

export interface FlowState {
  massFlowKgH: number
  designFlowKgH: number
  pressureBar: number
}

export interface EnergyMetrics {
  powerKw: number
  cumulativeKwh: number
  // GPU tile the equipment's kernels are pinned to.
  cudaTileId: number
  // Kernel throughput reported by the CUDA layer.
  kernelUtilization: number
}

export interface EquipmentComponent {
  id: string
  label: string
  // Reference to the binary flag key that gates this component.
  boundFlag: string
}

export interface Equipment {
  tag: string // e.g. "R101"
  name: string
  type: EquipmentType
  status: OperationalStatus
  // World-space position on the plant floor [x, y, z].
  position: [number, number, number]
  description: string
  components: EquipmentComponent[]
  binary: BinaryFlag[]
  thermal: ThermalState
  flow: FlowState
  energy: EnergyMetrics
}

// Connections between units (feed path through the plant).
export interface PipeLink {
  from: string
  to: string
}

function flag(
  bit: number,
  key: string,
  label: string,
  value: 0 | 1,
  activeIsHealthy = true,
): BinaryFlag {
  return { bit, key, label, value, activeIsHealthy }
}

export const PLANT_EQUIPMENT: Equipment[] = [
  {
    tag: "T101",
    name: "Toluene Feed Tank",
    type: "tank",
    status: "running",
    position: [-9, 0, 2],
    description: "Bulk toluene storage feeding the disproportionation loop.",
    components: [
      { id: "t101-shell", label: "Storage Shell", boundFlag: "level_ok" },
      { id: "t101-outlet", label: "Outlet Valve", boundFlag: "outlet_open" },
      { id: "t101-vent", label: "N2 Blanket Vent", boundFlag: "blanket_on" },
    ],
    binary: [
      flag(0, "power", "Power", 1),
      flag(1, "level_ok", "Level OK", 1),
      flag(2, "outlet_open", "Outlet Open", 1),
      flag(3, "blanket_on", "N2 Blanket", 1),
      flag(4, "hi_level", "High Level Alarm", 0, false),
      flag(5, "lo_level", "Low Level Alarm", 0, false),
      flag(6, "interlock", "Interlock", 0, false),
      flag(7, "maint", "Maintenance", 0, false),
    ],
    thermal: { temperatureC: 28, setpointC: 25, dutyFraction: 0.08 },
    flow: { massFlowKgH: 4200, designFlowKgH: 5000, pressureBar: 1.4 },
    energy: { powerKw: 6, cumulativeKwh: 14820, cudaTileId: 0, kernelUtilization: 0.12 },
  },
  {
    tag: "P101",
    name: "Feed Pump",
    type: "pump",
    status: "running",
    position: [-5, 0, 2],
    description: "Centrifugal pump raising toluene feed to reactor pressure.",
    components: [
      { id: "p101-motor", label: "Drive Motor", boundFlag: "motor_run" },
      { id: "p101-seal", label: "Mechanical Seal", boundFlag: "seal_ok" },
      { id: "p101-vfd", label: "VFD Drive", boundFlag: "vfd_ready" },
    ],
    binary: [
      flag(0, "power", "Power", 1),
      flag(1, "motor_run", "Motor Running", 1),
      flag(2, "vfd_ready", "VFD Ready", 1),
      flag(3, "seal_ok", "Seal Healthy", 1),
      flag(4, "cavitation", "Cavitation", 0, false),
      flag(5, "overcurrent", "Overcurrent", 0, false),
      flag(6, "interlock", "Interlock", 0, false),
      flag(7, "maint", "Maintenance", 0, false),
    ],
    thermal: { temperatureC: 46, setpointC: 45, dutyFraction: 0.33 },
    flow: { massFlowKgH: 4200, designFlowKgH: 5200, pressureBar: 18.5 },
    energy: { powerKw: 55, cumulativeKwh: 132400, cudaTileId: 1, kernelUtilization: 0.41 },
  },
  {
    tag: "H101",
    name: "Feed Preheater",
    type: "heater",
    status: "standby",
    position: [-1, 0, 2],
    description: "Fired heater bringing feed to reaction temperature.",
    components: [
      { id: "h101-burner", label: "Burner", boundFlag: "burner_on" },
      { id: "h101-coil", label: "Process Coil", boundFlag: "coil_flow" },
      { id: "h101-stack", label: "Stack Damper", boundFlag: "damper_open" },
    ],
    binary: [
      flag(0, "power", "Power", 1),
      flag(1, "burner_on", "Burner On", 0),
      flag(2, "coil_flow", "Coil Flow", 1),
      flag(3, "damper_open", "Damper Open", 1),
      flag(4, "flame_fail", "Flame Fail", 0, false),
      flag(5, "hi_temp", "High Temp", 0, false),
      flag(6, "interlock", "Interlock", 0, false),
      flag(7, "maint", "Maintenance", 0, false),
    ],
    thermal: { temperatureC: 312, setpointC: 480, dutyFraction: 0.52 },
    flow: { massFlowKgH: 4200, designFlowKgH: 5200, pressureBar: 17.9 },
    energy: { powerKw: 890, cumulativeKwh: 2140000, cudaTileId: 2, kernelUtilization: 0.58 },
  },
  {
    tag: "R101",
    name: "Disproportionation Reactor",
    type: "reactor",
    status: "running",
    position: [3, 0, 2],
    description: "Fixed-bed reactor converting toluene to benzene and xylene.",
    components: [
      { id: "r101-bed", label: "Catalyst Bed", boundFlag: "bed_active" },
      { id: "r101-jacket", label: "Cooling Jacket", boundFlag: "jacket_flow" },
      { id: "r101-inlet", label: "Inlet Distributor", boundFlag: "feed_in" },
      { id: "r101-relief", label: "Relief Valve", boundFlag: "relief_ok" },
    ],
    binary: [
      flag(0, "power", "Power", 1),
      flag(1, "bed_active", "Bed Active", 1),
      flag(2, "feed_in", "Feed Inlet", 1),
      flag(3, "jacket_flow", "Jacket Flow", 1),
      flag(4, "relief_ok", "Relief Healthy", 1),
      flag(5, "hi_temp", "High Temp", 0, false),
      flag(6, "interlock", "Interlock", 0, false),
      flag(7, "maint", "Maintenance", 0, false),
    ],
    thermal: { temperatureC: 471, setpointC: 470, dutyFraction: 0.81 },
    flow: { massFlowKgH: 4180, designFlowKgH: 5200, pressureBar: 17.2 },
    energy: { powerKw: 120, cumulativeKwh: 402000, cudaTileId: 3, kernelUtilization: 0.86 },
  },
  {
    tag: "C101",
    name: "Product Column",
    type: "column",
    status: "fault",
    position: [8, 0, 2],
    description: "Distillation column separating benzene, toluene and xylene.",
    components: [
      { id: "c101-reboiler", label: "Reboiler", boundFlag: "reboiler_on" },
      { id: "c101-condenser", label: "Condenser", boundFlag: "condenser_ok" },
      { id: "c101-reflux", label: "Reflux Pump", boundFlag: "reflux_run" },
      { id: "c101-trays", label: "Tray Section", boundFlag: "dp_ok" },
    ],
    binary: [
      flag(0, "power", "Power", 1),
      flag(1, "reboiler_on", "Reboiler On", 1),
      flag(2, "condenser_ok", "Condenser OK", 1),
      flag(3, "reflux_run", "Reflux Running", 0),
      flag(4, "dp_ok", "Column dP OK", 0, true),
      flag(5, "flood", "Flooding", 1, false),
      flag(6, "interlock", "Interlock", 1, false),
      flag(7, "maint", "Maintenance", 0, false),
    ],
    thermal: { temperatureC: 168, setpointC: 145, dutyFraction: 0.94 },
    flow: { massFlowKgH: 4180, designFlowKgH: 5200, pressureBar: 2.1 },
    energy: { powerKw: 640, cumulativeKwh: 1580000, cudaTileId: 4, kernelUtilization: 0.73 },
  },
]

export const PLANT_PIPES: PipeLink[] = [
  { from: "T101", to: "P101" },
  { from: "P101", to: "H101" },
  { from: "H101", to: "R101" },
  { from: "R101", to: "C101" },
]

// Compose the 8-bit binary state register as an integer + string.
export function registerValue(eq: Equipment): number {
  return eq.binary.reduce((acc, f) => acc | (f.value << f.bit), 0)
}

export function registerBits(eq: Equipment): string {
  const val = registerValue(eq)
  return val.toString(2).padStart(8, "0")
}

export function statusColor(status: OperationalStatus): string {
  switch (status) {
    case "running":
      return "var(--status-run)"
    case "standby":
      return "var(--status-standby)"
    case "fault":
      return "var(--status-fault)"
    default:
      return "var(--status-idle)"
  }
}

// Flags currently in an unhealthy state (used for the alarm rollup).
// An "activeIsHealthy" flag is faulted when low; an alarm flag is faulted when high.
export function activeFaults(eq: Equipment): BinaryFlag[] {
  return eq.binary.filter((f) => (f.activeIsHealthy ? f.value === 0 : f.value === 1))
}
