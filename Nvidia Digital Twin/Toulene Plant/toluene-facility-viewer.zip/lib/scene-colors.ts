import type { OperationalStatus } from "@/lib/plant-data"

// Hex equivalents of the CSS status tokens for use inside the WebGL canvas.
export const STATUS_HEX: Record<OperationalStatus, string> = {
  running: "#3fcf8e",
  standby: "#e6c04a",
  fault: "#e5484d",
  idle: "#8b8f98",
}

export const EQUIPMENT_BASE = "#9aa2ad"
export const EQUIPMENT_DARK = "#5b616b"
export const PIPE_COLOR = "#7d8590"
export const FLOOR_COLOR = "#20242c"
export const GRID_COLOR = "#333a44"
export const ACCENT_HEX = "#f0a94b"
